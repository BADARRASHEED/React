import React from "react";

const HeaderSocials = () => {
  return (
    <div className="home_socials">
      <a
        href="https://www.instagram.com/"
        className="home_social_link"
        target="_blank"
      >
        <i className="fa-brands fa-instagram"></i>
      </a>

      <a
        href="https://www.twitter.com/"
        className="home_social_link"
        target="_blank"
      >
        <i className="fa-brands fa-twitter"></i>
      </a>

      <a
        href="https://www.behance.com/"
        className="home_social_link"
        target="_blank"
      >
        <i className="fa-brands fa-behance"></i>
      </a>

      <a
        href="https://www.dribbble.com/"
        className="home_social_link"
        target="_blank"
      >
        <i className="fa-brands fa-dribbble"></i>
      </a>

      <a
        href="https://www.pinterest.com/"
        className="home_social_link"
        target="_blank"
      >
        <i className="fa-brands fa-pinterest"></i>
      </a>
    </div>
  );
};

export default HeaderSocials;
